import os,sys
import numpy as np

atomTypes = [l.rstrip().split()[0] for l in open("atomTypes.txt","r")]

def getAtomTyes(ff):
    atomTypesCount = {}
    fin = open(ff,"r")
    flag = 1
    atomTypes = 0	
    for line in fin:
	token = line.rstrip().split()
	try:
	   if token[0]=="GROUP":
		flag=0	
	   if token[0]=="MASS": flag=1 	
	   if token[0]=="ATOM" and flag==0:
	      at = token[2].split("_")[0]	
	      if at not in atomTypesCount: 
		  atomTypesCount[at] = 1
	      else: atomTypesCount[at] = atomTypesCount[at]+1
	except IndexError:continue
    fin.close()
    return atomTypesCount	


if __name__=="__main__":
   fout = open("atomTypesCount.txt","w")
   print>>fout,"Mol "
   for t in atomTypes: print>>fout,t,	 
   fout.write("\n")
   for m in os.listdir("."):
	if os.path.isdir(m):
	    print m
	    counts = getAtomTyes(m+"/ff.str")
	    print>>fout,m,	
	    for t in atomTypes: 
		if counts.has_key(t):
		   print>>fout,counts[t],
		else: print>>fout,0,	
	    fout.write("\n") 	
   fout.close()
    
